str="this is a string"
n=${#str}
echo "Length of the string is : $n "

